import Vue from 'vue'
import * as lodash from 'lodash'
Vue.prototype.$lodash = lodash
