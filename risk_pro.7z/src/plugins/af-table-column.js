import Vue from 'vue'
import AFTableColumn from 'af-table-column'
Vue.use(AFTableColumn)
